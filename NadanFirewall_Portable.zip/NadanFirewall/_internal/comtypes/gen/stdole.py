from enum import IntFlag

import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 as __wrapper_module__
from comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 import (
    Default, FONTSIZE, Library, DISPPROPERTY, FONTSTRIKETHROUGH,
    OLE_XSIZE_PIXELS, FONTUNDERSCORE, OLE_HANDLE, BSTR, FONTBOLD,
    dispid, IFontDisp, OLE_XPOS_CONTAINER, VgaColor,
    OLE_XPOS_HIMETRIC, OLE_CANCELBOOL, IUnknown, OLE_XSIZE_HIMETRIC,
    OLE_YSIZE_CONTAINER, CoClass, Font, _lcid, OLE_YPOS_CONTAINER,
    typelib_path, Unchecked, OLE_ENABLEDEFAULTBOOL, IPictureDisp,
    FontEvents, IPicture, Monochrome, IFont, IDispatch, OLE_COLOR,
    COMMETHOD, FONTNAME, Checked, OLE_YPOS_HIMETRIC, StdFont, HRESULT,
    EXCEPINFO, StdPicture, Picture, FONTITALIC, DISPPARAMS, GUID,
    DISPMETHOD, VARIANT_BOOL, Color, IEnumVARIANT, OLE_OPTEXCLUSIVE,
    IFontEventsDisp, OLE_XSIZE_CONTAINER, OLE_YSIZE_HIMETRIC,
    OLE_YSIZE_PIXELS, OLE_YPOS_PIXELS, OLE_XPOS_PIXELS,
    _check_version, Gray
)


class LoadPictureConstants(IntFlag):
    Default = 0
    Monochrome = 1
    VgaColor = 2
    Color = 4


class OLE_TRISTATE(IntFlag):
    Unchecked = 0
    Checked = 1
    Gray = 2


__all__ = [
    'IPictureDisp', 'Default', 'FontEvents', 'FONTSIZE', 'Library',
    'IPicture', 'Monochrome', 'FONTSTRIKETHROUGH', 'OLE_XSIZE_PIXELS',
    'FONTUNDERSCORE', 'OLE_HANDLE', 'FONTBOLD', 'OLE_COLOR',
    'IFontDisp', 'Unchecked', 'FONTNAME', 'Checked',
    'OLE_YPOS_HIMETRIC', 'OLE_ENABLEDEFAULTBOOL', 'StdFont',
    'OLE_XPOS_CONTAINER', 'StdPicture', 'VgaColor',
    'OLE_XPOS_HIMETRIC', 'Picture', 'FONTITALIC', 'OLE_CANCELBOOL',
    'OLE_TRISTATE', 'OLE_XSIZE_HIMETRIC', 'OLE_YSIZE_CONTAINER',
    'Font', 'Color', 'OLE_XPOS_PIXELS', 'OLE_OPTEXCLUSIVE', 'Gray',
    'IFontEventsDisp', 'OLE_YPOS_CONTAINER', 'OLE_XSIZE_CONTAINER',
    'OLE_YSIZE_HIMETRIC', 'OLE_YSIZE_PIXELS', 'OLE_YPOS_PIXELS',
    'typelib_path', 'LoadPictureConstants', 'IFont'
]

