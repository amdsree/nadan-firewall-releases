# -*- coding: mbcs -*-

from ctypes import *
import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0
from comtypes import _check_version, BSTR, COMMETHOD, dispid, GUID, IUnknown
from comtypes.automation import VARIANT
from ctypes import HRESULT
from ctypes.wintypes import VARIANT_BOOL
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from comtypes import hints


_lcid = 0  # change this if required
typelib_path = 'C:\\Windows\\System32\\FirewallAPI.dll'

# values for enumeration 'NET_FW_PROFILE_TYPE2_'
NET_FW_PROFILE2_DOMAIN = 1
NET_FW_PROFILE2_PRIVATE = 2
NET_FW_PROFILE2_PUBLIC = 4
NET_FW_PROFILE2_ALL = 2147483647
NET_FW_PROFILE_TYPE2_ = c_int  # enum

# values for enumeration 'NET_FW_ACTION_'
NET_FW_ACTION_BLOCK = 0
NET_FW_ACTION_ALLOW = 1
NET_FW_ACTION_MAX = 2
NET_FW_ACTION_ = c_int  # enum

# values for enumeration 'NET_FW_MODIFY_STATE_'
NET_FW_MODIFY_STATE_OK = 0
NET_FW_MODIFY_STATE_GP_OVERRIDE = 1
NET_FW_MODIFY_STATE_INBOUND_BLOCKED = 2
NET_FW_MODIFY_STATE_ = c_int  # enum

# values for enumeration 'NET_FW_SCOPE_'
NET_FW_SCOPE_ALL = 0
NET_FW_SCOPE_LOCAL_SUBNET = 1
NET_FW_SCOPE_CUSTOM = 2
NET_FW_SCOPE_MAX = 3
NET_FW_SCOPE_ = c_int  # enum

# values for enumeration 'NET_FW_RULE_DIRECTION_'
NET_FW_RULE_DIR_IN = 1
NET_FW_RULE_DIR_OUT = 2
NET_FW_RULE_DIR_MAX = 3
NET_FW_RULE_DIRECTION_ = c_int  # enum

# values for enumeration 'NET_FW_SERVICE_TYPE_'
NET_FW_SERVICE_FILE_AND_PRINT = 0
NET_FW_SERVICE_UPNP = 1
NET_FW_SERVICE_REMOTE_DESKTOP = 2
NET_FW_SERVICE_NONE = 3
NET_FW_SERVICE_TYPE_MAX = 4
NET_FW_SERVICE_TYPE_ = c_int  # enum

# values for enumeration 'NET_FW_PROFILE_TYPE_'
NET_FW_PROFILE_DOMAIN = 0
NET_FW_PROFILE_STANDARD = 1
NET_FW_PROFILE_CURRENT = 2
NET_FW_PROFILE_TYPE_MAX = 3
NET_FW_PROFILE_TYPE_ = c_int  # enum

# values for enumeration 'NET_FW_IP_VERSION_'
NET_FW_IP_VERSION_V4 = 0
NET_FW_IP_VERSION_V6 = 1
NET_FW_IP_VERSION_ANY = 2
NET_FW_IP_VERSION_MAX = 3
NET_FW_IP_VERSION_ = c_int  # enum

# values for enumeration 'NET_FW_IP_PROTOCOL_'
NET_FW_IP_PROTOCOL_TCP = 6
NET_FW_IP_PROTOCOL_UDP = 17
NET_FW_IP_PROTOCOL_ANY = 256
NET_FW_IP_PROTOCOL_ = c_int  # enum



class INetFwProduct(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{71881699-18F4-458B-B892-3FFCE5E07F75}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_RuleCategories(self) -> hints.Incomplete: ...
        def _set_RuleCategories(self, RuleCategories: hints.Incomplete) -> hints.Hresult: ...
        RuleCategories = hints.normal_property(_get_RuleCategories, _set_RuleCategories)
        def _get_DisplayName(self) -> hints.Incomplete: ...
        def _set_DisplayName(self, DisplayName: hints.Incomplete) -> hints.Hresult: ...
        DisplayName = hints.normal_property(_get_DisplayName, _set_DisplayName)
        def _get_PathToSignedProductExe(self) -> hints.Incomplete: ...
        PathToSignedProductExe = hints.normal_property(_get_PathToSignedProductExe)


INetFwProduct._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'RuleCategories',
        (['out', 'retval'], POINTER(VARIANT), 'RuleCategories')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'RuleCategories',
        (['in'], VARIANT, 'RuleCategories')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'DisplayName',
        (['out', 'retval'], POINTER(BSTR), 'DisplayName')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'DisplayName',
        (['in'], BSTR, 'DisplayName')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'PathToSignedProductExe',
        (['out', 'retval'], POINTER(BSTR), 'path')
    ),
]

################################################################
# code template for INetFwProduct implementation
# class INetFwProduct_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return RuleCategories
#     def _set(self, RuleCategories):
#         '-no docstring-'
#     RuleCategories = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return DisplayName
#     def _set(self, DisplayName):
#         '-no docstring-'
#     DisplayName = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def PathToSignedProductExe(self):
#         '-no docstring-'
#         #return path
#


class INetFwProducts(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{39EB36E0-2097-40BD-8AF2-63A13B525362}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Count(self) -> hints.Incomplete: ...
        Count = hints.normal_property(_get_Count)
        __len__ = hints.to_dunder_len(Count)
        def Register(self, product: hints.Incomplete) -> hints.Incomplete: ...
        def Item(self, index: hints.Incomplete) -> 'INetFwProduct': ...
        __call__ = hints.to_dunder_call(Item)
        __getitem__ = hints.to_dunder_getitem(Item)
        __setitem__ = hints.to_dunder_setitem(Item)
        def _get__NewEnum(self) -> hints.Incomplete: ...
        _NewEnum = hints.normal_property(_get__NewEnum)
        __iter__ = hints.to_dunder_iter(_NewEnum)


INetFwProducts._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Count',
        (['out', 'retval'], POINTER(c_int), 'Count')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'Register',
        (['in'], POINTER(INetFwProduct), 'product'),
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'registration')
    ),
    COMMETHOD(
        [dispid(3)],
        HRESULT,
        'Item',
        (['in'], c_int, 'index'),
        (['out', 'retval'], POINTER(POINTER(INetFwProduct)), 'product')
    ),
    COMMETHOD(
        [dispid(-4), 'restricted', 'propget'],
        HRESULT,
        '_NewEnum',
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'newEnum')
    ),
]

################################################################
# code template for INetFwProducts implementation
# class INetFwProducts_Impl(object):
#     @property
#     def Count(self):
#         '-no docstring-'
#         #return Count
#
#     def Register(self, product):
#         '-no docstring-'
#         #return registration
#
#     def Item(self, index):
#         '-no docstring-'
#         #return product
#
#     @property
#     def _NewEnum(self):
#         '-no docstring-'
#         #return newEnum
#


class INetFwPolicy2(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{98325047-C671-4174-8D81-DEFCD3F03186}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_CurrentProfileTypes(self) -> hints.Incomplete: ...
        CurrentProfileTypes = hints.normal_property(_get_CurrentProfileTypes)
        def _get_FirewallEnabled(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_FirewallEnabled(self, profileType: hints.Incomplete, Enabled: hints.Incomplete) -> hints.Hresult: ...
        FirewallEnabled = hints.named_property('FirewallEnabled', _get_FirewallEnabled, _set_FirewallEnabled)
        def _get_ExcludedInterfaces(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_ExcludedInterfaces(self, profileType: hints.Incomplete, Interfaces: hints.Incomplete) -> hints.Hresult: ...
        ExcludedInterfaces = hints.named_property('ExcludedInterfaces', _get_ExcludedInterfaces, _set_ExcludedInterfaces)
        def _get_BlockAllInboundTraffic(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_BlockAllInboundTraffic(self, profileType: hints.Incomplete, Block: hints.Incomplete) -> hints.Hresult: ...
        BlockAllInboundTraffic = hints.named_property('BlockAllInboundTraffic', _get_BlockAllInboundTraffic, _set_BlockAllInboundTraffic)
        def _get_NotificationsDisabled(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_NotificationsDisabled(self, profileType: hints.Incomplete, disabled: hints.Incomplete) -> hints.Hresult: ...
        NotificationsDisabled = hints.named_property('NotificationsDisabled', _get_NotificationsDisabled, _set_NotificationsDisabled)
        def _get_UnicastResponsesToMulticastBroadcastDisabled(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_UnicastResponsesToMulticastBroadcastDisabled(self, profileType: hints.Incomplete, disabled: hints.Incomplete) -> hints.Hresult: ...
        UnicastResponsesToMulticastBroadcastDisabled = hints.named_property('UnicastResponsesToMulticastBroadcastDisabled', _get_UnicastResponsesToMulticastBroadcastDisabled, _set_UnicastResponsesToMulticastBroadcastDisabled)
        def _get_Rules(self) -> 'INetFwRules': ...
        Rules = hints.normal_property(_get_Rules)
        def _get_ServiceRestriction(self) -> 'INetFwServiceRestriction': ...
        ServiceRestriction = hints.normal_property(_get_ServiceRestriction)
        def EnableRuleGroup(self, profileTypesBitmask: hints.Incomplete, group: hints.Incomplete, enable: hints.Incomplete) -> hints.Hresult: ...
        def IsRuleGroupEnabled(self, profileTypesBitmask: hints.Incomplete, group: hints.Incomplete) -> hints.Incomplete: ...
        def RestoreLocalFirewallDefaults(self) -> hints.Hresult: ...
        def _get_DefaultInboundAction(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_DefaultInboundAction(self, profileType: hints.Incomplete, Action: hints.Incomplete) -> hints.Hresult: ...
        DefaultInboundAction = hints.named_property('DefaultInboundAction', _get_DefaultInboundAction, _set_DefaultInboundAction)
        def _get_DefaultOutboundAction(self, profileType: hints.Incomplete) -> hints.Incomplete: ...
        def _set_DefaultOutboundAction(self, profileType: hints.Incomplete, Action: hints.Incomplete) -> hints.Hresult: ...
        DefaultOutboundAction = hints.named_property('DefaultOutboundAction', _get_DefaultOutboundAction, _set_DefaultOutboundAction)
        def _get_IsRuleGroupCurrentlyEnabled(self, group: hints.Incomplete) -> hints.Incomplete: ...
        IsRuleGroupCurrentlyEnabled = hints.named_property('IsRuleGroupCurrentlyEnabled', _get_IsRuleGroupCurrentlyEnabled)
        def _get_LocalPolicyModifyState(self) -> hints.Incomplete: ...
        LocalPolicyModifyState = hints.normal_property(_get_LocalPolicyModifyState)


class INetFwRules(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{9C4C6277-5027-441E-AFAE-CA1F542DA009}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Count(self) -> hints.Incomplete: ...
        Count = hints.normal_property(_get_Count)
        __len__ = hints.to_dunder_len(Count)
        def Add(self, rule: hints.Incomplete) -> hints.Hresult: ...
        def Remove(self, Name: hints.Incomplete) -> hints.Hresult: ...
        def Item(self, Name: hints.Incomplete) -> 'INetFwRule': ...
        __call__ = hints.to_dunder_call(Item)
        __getitem__ = hints.to_dunder_getitem(Item)
        __setitem__ = hints.to_dunder_setitem(Item)
        def _get__NewEnum(self) -> hints.Incomplete: ...
        _NewEnum = hints.normal_property(_get__NewEnum)
        __iter__ = hints.to_dunder_iter(_NewEnum)


class INetFwServiceRestriction(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{8267BBE3-F890-491C-B7B6-2DB1EF0E5D2B}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def RestrictService(self, serviceName: hints.Incomplete, appName: hints.Incomplete, RestrictService: hints.Incomplete, serviceSidRestricted: hints.Incomplete) -> hints.Hresult: ...
        def ServiceRestricted(self, serviceName: hints.Incomplete, appName: hints.Incomplete) -> hints.Incomplete: ...
        def _get_Rules(self) -> 'INetFwRules': ...
        Rules = hints.normal_property(_get_Rules)


INetFwPolicy2._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'CurrentProfileTypes',
        (['out', 'retval'], POINTER(c_int), 'profileTypesBitmask')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'FirewallEnabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'FirewallEnabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'ExcludedInterfaces',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(VARIANT), 'Interfaces')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'ExcludedInterfaces',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], VARIANT, 'Interfaces')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'BlockAllInboundTraffic',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Block')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'BlockAllInboundTraffic',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], VARIANT_BOOL, 'Block')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'NotificationsDisabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'disabled')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'NotificationsDisabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], VARIANT_BOOL, 'disabled')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'UnicastResponsesToMulticastBroadcastDisabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'disabled')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'UnicastResponsesToMulticastBroadcastDisabled',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], VARIANT_BOOL, 'disabled')
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'Rules',
        (['out', 'retval'], POINTER(POINTER(INetFwRules)), 'Rules')
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'ServiceRestriction',
        (
            ['out', 'retval'],
            POINTER(POINTER(INetFwServiceRestriction)),
            'ServiceRestriction',
        )
    ),
    COMMETHOD(
        [dispid(9)],
        HRESULT,
        'EnableRuleGroup',
        (['in'], c_int, 'profileTypesBitmask'),
        (['in'], BSTR, 'group'),
        (['in'], VARIANT_BOOL, 'enable')
    ),
    COMMETHOD(
        [dispid(10)],
        HRESULT,
        'IsRuleGroupEnabled',
        (['in'], c_int, 'profileTypesBitmask'),
        (['in'], BSTR, 'group'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD([dispid(11)], HRESULT, 'RestoreLocalFirewallDefaults'),
    COMMETHOD(
        [dispid(12), 'propget'],
        HRESULT,
        'DefaultInboundAction',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(NET_FW_ACTION_), 'Action')
    ),
    COMMETHOD(
        [dispid(12), 'propput'],
        HRESULT,
        'DefaultInboundAction',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], NET_FW_ACTION_, 'Action')
    ),
    COMMETHOD(
        [dispid(13), 'propget'],
        HRESULT,
        'DefaultOutboundAction',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['out', 'retval'], POINTER(NET_FW_ACTION_), 'Action')
    ),
    COMMETHOD(
        [dispid(13), 'propput'],
        HRESULT,
        'DefaultOutboundAction',
        (['in'], NET_FW_PROFILE_TYPE2_, 'profileType'),
        (['in'], NET_FW_ACTION_, 'Action')
    ),
    COMMETHOD(
        [dispid(14), 'propget'],
        HRESULT,
        'IsRuleGroupCurrentlyEnabled',
        (['in'], BSTR, 'group'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(15), 'propget'],
        HRESULT,
        'LocalPolicyModifyState',
        (['out', 'retval'], POINTER(NET_FW_MODIFY_STATE_), 'modifyState')
    ),
]

################################################################
# code template for INetFwPolicy2 implementation
# class INetFwPolicy2_Impl(object):
#     @property
#     def CurrentProfileTypes(self):
#         '-no docstring-'
#         #return profileTypesBitmask
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, profileType, Enabled):
#         '-no docstring-'
#     FirewallEnabled = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return Interfaces
#     def _set(self, profileType, Interfaces):
#         '-no docstring-'
#     ExcludedInterfaces = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return Block
#     def _set(self, profileType, Block):
#         '-no docstring-'
#     BlockAllInboundTraffic = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return disabled
#     def _set(self, profileType, disabled):
#         '-no docstring-'
#     NotificationsDisabled = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return disabled
#     def _set(self, profileType, disabled):
#         '-no docstring-'
#     UnicastResponsesToMulticastBroadcastDisabled = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def Rules(self):
#         '-no docstring-'
#         #return Rules
#
#     @property
#     def ServiceRestriction(self):
#         '-no docstring-'
#         #return ServiceRestriction
#
#     def EnableRuleGroup(self, profileTypesBitmask, group, enable):
#         '-no docstring-'
#         #return 
#
#     def IsRuleGroupEnabled(self, profileTypesBitmask, group):
#         '-no docstring-'
#         #return Enabled
#
#     def RestoreLocalFirewallDefaults(self):
#         '-no docstring-'
#         #return 
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return Action
#     def _set(self, profileType, Action):
#         '-no docstring-'
#     DefaultInboundAction = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self, profileType):
#         '-no docstring-'
#         #return Action
#     def _set(self, profileType, Action):
#         '-no docstring-'
#     DefaultOutboundAction = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def IsRuleGroupCurrentlyEnabled(self, group):
#         '-no docstring-'
#         #return Enabled
#
#     @property
#     def LocalPolicyModifyState(self):
#         '-no docstring-'
#         #return modifyState
#


class INetFwRule(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{AF230D27-BABA-4E42-ACED-F524F22CFCE2}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Name(self) -> hints.Incomplete: ...
        def _set_Name(self, Name: hints.Incomplete) -> hints.Hresult: ...
        Name = hints.normal_property(_get_Name, _set_Name)
        def _get_Description(self) -> hints.Incomplete: ...
        def _set_Description(self, desc: hints.Incomplete) -> hints.Hresult: ...
        Description = hints.normal_property(_get_Description, _set_Description)
        def _get_ApplicationName(self) -> hints.Incomplete: ...
        def _set_ApplicationName(self, imageFileName: hints.Incomplete) -> hints.Hresult: ...
        ApplicationName = hints.normal_property(_get_ApplicationName, _set_ApplicationName)
        def _get_serviceName(self) -> hints.Incomplete: ...
        def _set_serviceName(self, serviceName: hints.Incomplete) -> hints.Hresult: ...
        serviceName = hints.normal_property(_get_serviceName, _set_serviceName)
        def _get_Protocol(self) -> hints.Incomplete: ...
        def _set_Protocol(self, Protocol: hints.Incomplete) -> hints.Hresult: ...
        Protocol = hints.normal_property(_get_Protocol, _set_Protocol)
        def _get_LocalPorts(self) -> hints.Incomplete: ...
        def _set_LocalPorts(self, portNumbers: hints.Incomplete) -> hints.Hresult: ...
        LocalPorts = hints.normal_property(_get_LocalPorts, _set_LocalPorts)
        def _get_RemotePorts(self) -> hints.Incomplete: ...
        def _set_RemotePorts(self, portNumbers: hints.Incomplete) -> hints.Hresult: ...
        RemotePorts = hints.normal_property(_get_RemotePorts, _set_RemotePorts)
        def _get_LocalAddresses(self) -> hints.Incomplete: ...
        def _set_LocalAddresses(self, localAddrs: hints.Incomplete) -> hints.Hresult: ...
        LocalAddresses = hints.normal_property(_get_LocalAddresses, _set_LocalAddresses)
        def _get_RemoteAddresses(self) -> hints.Incomplete: ...
        def _set_RemoteAddresses(self, remoteAddrs: hints.Incomplete) -> hints.Hresult: ...
        RemoteAddresses = hints.normal_property(_get_RemoteAddresses, _set_RemoteAddresses)
        def _get_IcmpTypesAndCodes(self) -> hints.Incomplete: ...
        def _set_IcmpTypesAndCodes(self, IcmpTypesAndCodes: hints.Incomplete) -> hints.Hresult: ...
        IcmpTypesAndCodes = hints.normal_property(_get_IcmpTypesAndCodes, _set_IcmpTypesAndCodes)
        def _get_Direction(self) -> hints.Incomplete: ...
        def _set_Direction(self, dir: hints.Incomplete) -> hints.Hresult: ...
        Direction = hints.normal_property(_get_Direction, _set_Direction)
        def _get_Interfaces(self) -> hints.Incomplete: ...
        def _set_Interfaces(self, Interfaces: hints.Incomplete) -> hints.Hresult: ...
        Interfaces = hints.normal_property(_get_Interfaces, _set_Interfaces)
        def _get_InterfaceTypes(self) -> hints.Incomplete: ...
        def _set_InterfaceTypes(self, InterfaceTypes: hints.Incomplete) -> hints.Hresult: ...
        InterfaceTypes = hints.normal_property(_get_InterfaceTypes, _set_InterfaceTypes)
        def _get_Enabled(self) -> hints.Incomplete: ...
        def _set_Enabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        Enabled = hints.normal_property(_get_Enabled, _set_Enabled)
        def _get_Grouping(self) -> hints.Incomplete: ...
        def _set_Grouping(self, context: hints.Incomplete) -> hints.Hresult: ...
        Grouping = hints.normal_property(_get_Grouping, _set_Grouping)
        def _get_Profiles(self) -> hints.Incomplete: ...
        def _set_Profiles(self, profileTypesBitmask: hints.Incomplete) -> hints.Hresult: ...
        Profiles = hints.normal_property(_get_Profiles, _set_Profiles)
        def _get_EdgeTraversal(self) -> hints.Incomplete: ...
        def _set_EdgeTraversal(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        EdgeTraversal = hints.normal_property(_get_EdgeTraversal, _set_EdgeTraversal)
        def _get_Action(self) -> hints.Incomplete: ...
        def _set_Action(self, Action: hints.Incomplete) -> hints.Hresult: ...
        Action = hints.normal_property(_get_Action, _set_Action)


INetFwRule._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Name',
        (['out', 'retval'], POINTER(BSTR), 'Name')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'Name',
        (['in'], BSTR, 'Name')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'Description',
        (['out', 'retval'], POINTER(BSTR), 'desc')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'Description',
        (['in'], BSTR, 'desc')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'ApplicationName',
        (['out', 'retval'], POINTER(BSTR), 'imageFileName')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'ApplicationName',
        (['in'], BSTR, 'imageFileName')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'serviceName',
        (['out', 'retval'], POINTER(BSTR), 'serviceName')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'serviceName',
        (['in'], BSTR, 'serviceName')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'Protocol',
        (['out', 'retval'], POINTER(c_int), 'Protocol')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'Protocol',
        (['in'], c_int, 'Protocol')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'LocalPorts',
        (['out', 'retval'], POINTER(BSTR), 'portNumbers')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'LocalPorts',
        (['in'], BSTR, 'portNumbers')
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'RemotePorts',
        (['out', 'retval'], POINTER(BSTR), 'portNumbers')
    ),
    COMMETHOD(
        [dispid(7), 'propput'],
        HRESULT,
        'RemotePorts',
        (['in'], BSTR, 'portNumbers')
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'LocalAddresses',
        (['out', 'retval'], POINTER(BSTR), 'localAddrs')
    ),
    COMMETHOD(
        [dispid(8), 'propput'],
        HRESULT,
        'LocalAddresses',
        (['in'], BSTR, 'localAddrs')
    ),
    COMMETHOD(
        [dispid(9), 'propget'],
        HRESULT,
        'RemoteAddresses',
        (['out', 'retval'], POINTER(BSTR), 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(9), 'propput'],
        HRESULT,
        'RemoteAddresses',
        (['in'], BSTR, 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(10), 'propget'],
        HRESULT,
        'IcmpTypesAndCodes',
        (['out', 'retval'], POINTER(BSTR), 'IcmpTypesAndCodes')
    ),
    COMMETHOD(
        [dispid(10), 'propput'],
        HRESULT,
        'IcmpTypesAndCodes',
        (['in'], BSTR, 'IcmpTypesAndCodes')
    ),
    COMMETHOD(
        [dispid(11), 'propget'],
        HRESULT,
        'Direction',
        (['out', 'retval'], POINTER(NET_FW_RULE_DIRECTION_), 'dir')
    ),
    COMMETHOD(
        [dispid(11), 'propput'],
        HRESULT,
        'Direction',
        (['in'], NET_FW_RULE_DIRECTION_, 'dir')
    ),
    COMMETHOD(
        [dispid(12), 'propget'],
        HRESULT,
        'Interfaces',
        (['out', 'retval'], POINTER(VARIANT), 'Interfaces')
    ),
    COMMETHOD(
        [dispid(12), 'propput'],
        HRESULT,
        'Interfaces',
        (['in'], VARIANT, 'Interfaces')
    ),
    COMMETHOD(
        [dispid(13), 'propget'],
        HRESULT,
        'InterfaceTypes',
        (['out', 'retval'], POINTER(BSTR), 'InterfaceTypes')
    ),
    COMMETHOD(
        [dispid(13), 'propput'],
        HRESULT,
        'InterfaceTypes',
        (['in'], BSTR, 'InterfaceTypes')
    ),
    COMMETHOD(
        [dispid(14), 'propget'],
        HRESULT,
        'Enabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(14), 'propput'],
        HRESULT,
        'Enabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(15), 'propget'],
        HRESULT,
        'Grouping',
        (['out', 'retval'], POINTER(BSTR), 'context')
    ),
    COMMETHOD(
        [dispid(15), 'propput'],
        HRESULT,
        'Grouping',
        (['in'], BSTR, 'context')
    ),
    COMMETHOD(
        [dispid(16), 'propget'],
        HRESULT,
        'Profiles',
        (['out', 'retval'], POINTER(c_int), 'profileTypesBitmask')
    ),
    COMMETHOD(
        [dispid(16), 'propput'],
        HRESULT,
        'Profiles',
        (['in'], c_int, 'profileTypesBitmask')
    ),
    COMMETHOD(
        [dispid(17), 'propget'],
        HRESULT,
        'EdgeTraversal',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(17), 'propput'],
        HRESULT,
        'EdgeTraversal',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(18), 'propget'],
        HRESULT,
        'Action',
        (['out', 'retval'], POINTER(NET_FW_ACTION_), 'Action')
    ),
    COMMETHOD(
        [dispid(18), 'propput'],
        HRESULT,
        'Action',
        (['in'], NET_FW_ACTION_, 'Action')
    ),
]

################################################################
# code template for INetFwRule implementation
# class INetFwRule_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return Name
#     def _set(self, Name):
#         '-no docstring-'
#     Name = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return desc
#     def _set(self, desc):
#         '-no docstring-'
#     Description = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return imageFileName
#     def _set(self, imageFileName):
#         '-no docstring-'
#     ApplicationName = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return serviceName
#     def _set(self, serviceName):
#         '-no docstring-'
#     serviceName = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Protocol
#     def _set(self, Protocol):
#         '-no docstring-'
#     Protocol = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return portNumbers
#     def _set(self, portNumbers):
#         '-no docstring-'
#     LocalPorts = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return portNumbers
#     def _set(self, portNumbers):
#         '-no docstring-'
#     RemotePorts = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return localAddrs
#     def _set(self, localAddrs):
#         '-no docstring-'
#     LocalAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return remoteAddrs
#     def _set(self, remoteAddrs):
#         '-no docstring-'
#     RemoteAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return IcmpTypesAndCodes
#     def _set(self, IcmpTypesAndCodes):
#         '-no docstring-'
#     IcmpTypesAndCodes = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return dir
#     def _set(self, dir):
#         '-no docstring-'
#     Direction = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Interfaces
#     def _set(self, Interfaces):
#         '-no docstring-'
#     Interfaces = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return InterfaceTypes
#     def _set(self, InterfaceTypes):
#         '-no docstring-'
#     InterfaceTypes = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     Enabled = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return context
#     def _set(self, context):
#         '-no docstring-'
#     Grouping = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return profileTypesBitmask
#     def _set(self, profileTypesBitmask):
#         '-no docstring-'
#     Profiles = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     EdgeTraversal = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Action
#     def _set(self, Action):
#         '-no docstring-'
#     Action = property(_get, _set, doc = _set.__doc__)
#


class INetFwMgr(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{F7898AF5-CAC4-4632-A2EC-DA06E5111AF2}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_LocalPolicy(self) -> 'INetFwPolicy': ...
        LocalPolicy = hints.normal_property(_get_LocalPolicy)
        def _get_CurrentProfileType(self) -> hints.Incomplete: ...
        CurrentProfileType = hints.normal_property(_get_CurrentProfileType)
        def RestoreDefaults(self) -> hints.Hresult: ...
        def IsPortAllowed(self, imageFileName: hints.Incomplete, IpVersion: hints.Incomplete, portNumber: hints.Incomplete, localAddress: hints.Incomplete, ipProtocol: hints.Incomplete) -> tuple[hints.Incomplete, hints.Incomplete]: ...
        def IsIcmpTypeAllowed(self, IpVersion: hints.Incomplete, localAddress: hints.Incomplete, Type: hints.Incomplete) -> tuple[hints.Incomplete, hints.Incomplete]: ...


class INetFwPolicy(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{D46D2478-9AC9-4008-9DC7-5563CE5536CC}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_CurrentProfile(self) -> 'INetFwProfile': ...
        CurrentProfile = hints.normal_property(_get_CurrentProfile)
        def GetProfileByType(self, profileType: hints.Incomplete) -> 'INetFwProfile': ...


INetFwMgr._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'LocalPolicy',
        (['out', 'retval'], POINTER(POINTER(INetFwPolicy)), 'LocalPolicy')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'CurrentProfileType',
        (['out', 'retval'], POINTER(NET_FW_PROFILE_TYPE_), 'profileType')
    ),
    COMMETHOD([dispid(3)], HRESULT, 'RestoreDefaults'),
    COMMETHOD(
        [dispid(4)],
        HRESULT,
        'IsPortAllowed',
        (['in'], BSTR, 'imageFileName'),
        (['in'], NET_FW_IP_VERSION_, 'IpVersion'),
        (['in'], c_int, 'portNumber'),
        (['in'], BSTR, 'localAddress'),
        (['in'], NET_FW_IP_PROTOCOL_, 'ipProtocol'),
        (['out'], POINTER(VARIANT), 'allowed'),
        (['out'], POINTER(VARIANT), 'restricted')
    ),
    COMMETHOD(
        [dispid(5)],
        HRESULT,
        'IsIcmpTypeAllowed',
        (['in'], NET_FW_IP_VERSION_, 'IpVersion'),
        (['in'], BSTR, 'localAddress'),
        (['in'], c_ubyte, 'Type'),
        (['out'], POINTER(VARIANT), 'allowed'),
        (['out'], POINTER(VARIANT), 'restricted')
    ),
]

################################################################
# code template for INetFwMgr implementation
# class INetFwMgr_Impl(object):
#     @property
#     def LocalPolicy(self):
#         '-no docstring-'
#         #return LocalPolicy
#
#     @property
#     def CurrentProfileType(self):
#         '-no docstring-'
#         #return profileType
#
#     def RestoreDefaults(self):
#         '-no docstring-'
#         #return 
#
#     def IsPortAllowed(self, imageFileName, IpVersion, portNumber, localAddress, ipProtocol):
#         '-no docstring-'
#         #return allowed, restricted
#
#     def IsIcmpTypeAllowed(self, IpVersion, localAddress, Type):
#         '-no docstring-'
#         #return allowed, restricted
#


class INetFwProfile(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{174A0DDA-E9F9-449D-993B-21AB667CA456}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Type(self) -> hints.Incomplete: ...
        Type = hints.normal_property(_get_Type)
        def _get_FirewallEnabled(self) -> hints.Incomplete: ...
        def _set_FirewallEnabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        FirewallEnabled = hints.normal_property(_get_FirewallEnabled, _set_FirewallEnabled)
        def _get_ExceptionsNotAllowed(self) -> hints.Incomplete: ...
        def _set_ExceptionsNotAllowed(self, notAllowed: hints.Incomplete) -> hints.Hresult: ...
        ExceptionsNotAllowed = hints.normal_property(_get_ExceptionsNotAllowed, _set_ExceptionsNotAllowed)
        def _get_NotificationsDisabled(self) -> hints.Incomplete: ...
        def _set_NotificationsDisabled(self, disabled: hints.Incomplete) -> hints.Hresult: ...
        NotificationsDisabled = hints.normal_property(_get_NotificationsDisabled, _set_NotificationsDisabled)
        def _get_UnicastResponsesToMulticastBroadcastDisabled(self) -> hints.Incomplete: ...
        def _set_UnicastResponsesToMulticastBroadcastDisabled(self, disabled: hints.Incomplete) -> hints.Hresult: ...
        UnicastResponsesToMulticastBroadcastDisabled = hints.normal_property(_get_UnicastResponsesToMulticastBroadcastDisabled, _set_UnicastResponsesToMulticastBroadcastDisabled)
        def _get_RemoteAdminSettings(self) -> 'INetFwRemoteAdminSettings': ...
        RemoteAdminSettings = hints.normal_property(_get_RemoteAdminSettings)
        def _get_IcmpSettings(self) -> 'INetFwIcmpSettings': ...
        IcmpSettings = hints.normal_property(_get_IcmpSettings)
        def _get_GloballyOpenPorts(self) -> 'INetFwOpenPorts': ...
        GloballyOpenPorts = hints.normal_property(_get_GloballyOpenPorts)
        def _get_Services(self) -> 'INetFwServices': ...
        Services = hints.normal_property(_get_Services)
        def _get_AuthorizedApplications(self) -> 'INetFwAuthorizedApplications': ...
        AuthorizedApplications = hints.normal_property(_get_AuthorizedApplications)


class INetFwRemoteAdminSettings(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{D4BECDDF-6F73-4A83-B832-9C66874CD20E}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_IpVersion(self) -> hints.Incomplete: ...
        def _set_IpVersion(self, IpVersion: hints.Incomplete) -> hints.Hresult: ...
        IpVersion = hints.normal_property(_get_IpVersion, _set_IpVersion)
        def _get_Scope(self) -> hints.Incomplete: ...
        def _set_Scope(self, Scope: hints.Incomplete) -> hints.Hresult: ...
        Scope = hints.normal_property(_get_Scope, _set_Scope)
        def _get_RemoteAddresses(self) -> hints.Incomplete: ...
        def _set_RemoteAddresses(self, remoteAddrs: hints.Incomplete) -> hints.Hresult: ...
        RemoteAddresses = hints.normal_property(_get_RemoteAddresses, _set_RemoteAddresses)
        def _get_Enabled(self) -> hints.Incomplete: ...
        def _set_Enabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        Enabled = hints.normal_property(_get_Enabled, _set_Enabled)


class INetFwIcmpSettings(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{A6207B2E-7CDD-426A-951E-5E1CBC5AFEAD}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_AllowOutboundDestinationUnreachable(self) -> hints.Incomplete: ...
        def _set_AllowOutboundDestinationUnreachable(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowOutboundDestinationUnreachable = hints.normal_property(_get_AllowOutboundDestinationUnreachable, _set_AllowOutboundDestinationUnreachable)
        def _get_AllowRedirect(self) -> hints.Incomplete: ...
        def _set_AllowRedirect(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowRedirect = hints.normal_property(_get_AllowRedirect, _set_AllowRedirect)
        def _get_AllowInboundEchoRequest(self) -> hints.Incomplete: ...
        def _set_AllowInboundEchoRequest(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowInboundEchoRequest = hints.normal_property(_get_AllowInboundEchoRequest, _set_AllowInboundEchoRequest)
        def _get_AllowOutboundTimeExceeded(self) -> hints.Incomplete: ...
        def _set_AllowOutboundTimeExceeded(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowOutboundTimeExceeded = hints.normal_property(_get_AllowOutboundTimeExceeded, _set_AllowOutboundTimeExceeded)
        def _get_AllowOutboundParameterProblem(self) -> hints.Incomplete: ...
        def _set_AllowOutboundParameterProblem(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowOutboundParameterProblem = hints.normal_property(_get_AllowOutboundParameterProblem, _set_AllowOutboundParameterProblem)
        def _get_AllowOutboundSourceQuench(self) -> hints.Incomplete: ...
        def _set_AllowOutboundSourceQuench(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowOutboundSourceQuench = hints.normal_property(_get_AllowOutboundSourceQuench, _set_AllowOutboundSourceQuench)
        def _get_AllowInboundRouterRequest(self) -> hints.Incomplete: ...
        def _set_AllowInboundRouterRequest(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowInboundRouterRequest = hints.normal_property(_get_AllowInboundRouterRequest, _set_AllowInboundRouterRequest)
        def _get_AllowInboundTimestampRequest(self) -> hints.Incomplete: ...
        def _set_AllowInboundTimestampRequest(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowInboundTimestampRequest = hints.normal_property(_get_AllowInboundTimestampRequest, _set_AllowInboundTimestampRequest)
        def _get_AllowInboundMaskRequest(self) -> hints.Incomplete: ...
        def _set_AllowInboundMaskRequest(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowInboundMaskRequest = hints.normal_property(_get_AllowInboundMaskRequest, _set_AllowInboundMaskRequest)
        def _get_AllowOutboundPacketTooBig(self) -> hints.Incomplete: ...
        def _set_AllowOutboundPacketTooBig(self, allow: hints.Incomplete) -> hints.Hresult: ...
        AllowOutboundPacketTooBig = hints.normal_property(_get_AllowOutboundPacketTooBig, _set_AllowOutboundPacketTooBig)


class INetFwOpenPorts(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{C0E9D7FA-E07E-430A-B19A-090CE82D92E2}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Count(self) -> hints.Incomplete: ...
        Count = hints.normal_property(_get_Count)
        __len__ = hints.to_dunder_len(Count)
        def Add(self, Port: hints.Incomplete) -> hints.Hresult: ...
        def Remove(self, portNumber: hints.Incomplete, ipProtocol: hints.Incomplete) -> hints.Hresult: ...
        def Item(self, portNumber: hints.Incomplete, ipProtocol: hints.Incomplete) -> 'INetFwOpenPort': ...
        __call__ = hints.to_dunder_call(Item)
        __getitem__ = hints.to_dunder_getitem(Item)
        __setitem__ = hints.to_dunder_setitem(Item)
        def _get__NewEnum(self) -> hints.Incomplete: ...
        _NewEnum = hints.normal_property(_get__NewEnum)
        __iter__ = hints.to_dunder_iter(_NewEnum)


class INetFwServices(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{79649BB4-903E-421B-94C9-79848E79F6EE}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Count(self) -> hints.Incomplete: ...
        Count = hints.normal_property(_get_Count)
        __len__ = hints.to_dunder_len(Count)
        def Item(self, svcType: hints.Incomplete) -> 'INetFwService': ...
        __call__ = hints.to_dunder_call(Item)
        __getitem__ = hints.to_dunder_getitem(Item)
        __setitem__ = hints.to_dunder_setitem(Item)
        def _get__NewEnum(self) -> hints.Incomplete: ...
        _NewEnum = hints.normal_property(_get__NewEnum)
        __iter__ = hints.to_dunder_iter(_NewEnum)


class INetFwAuthorizedApplications(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{644EFD52-CCF9-486C-97A2-39F352570B30}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Count(self) -> hints.Incomplete: ...
        Count = hints.normal_property(_get_Count)
        __len__ = hints.to_dunder_len(Count)
        def Add(self, app: hints.Incomplete) -> hints.Hresult: ...
        def Remove(self, imageFileName: hints.Incomplete) -> hints.Hresult: ...
        def Item(self, imageFileName: hints.Incomplete) -> 'INetFwAuthorizedApplication': ...
        __call__ = hints.to_dunder_call(Item)
        __getitem__ = hints.to_dunder_getitem(Item)
        __setitem__ = hints.to_dunder_setitem(Item)
        def _get__NewEnum(self) -> hints.Incomplete: ...
        _NewEnum = hints.normal_property(_get__NewEnum)
        __iter__ = hints.to_dunder_iter(_NewEnum)


INetFwProfile._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Type',
        (['out', 'retval'], POINTER(NET_FW_PROFILE_TYPE_), 'Type')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'FirewallEnabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'FirewallEnabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'ExceptionsNotAllowed',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'notAllowed')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'ExceptionsNotAllowed',
        (['in'], VARIANT_BOOL, 'notAllowed')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'NotificationsDisabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'disabled')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'NotificationsDisabled',
        (['in'], VARIANT_BOOL, 'disabled')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'UnicastResponsesToMulticastBroadcastDisabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'disabled')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'UnicastResponsesToMulticastBroadcastDisabled',
        (['in'], VARIANT_BOOL, 'disabled')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'RemoteAdminSettings',
        (
            ['out', 'retval'],
            POINTER(POINTER(INetFwRemoteAdminSettings)),
            'RemoteAdminSettings',
        )
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'IcmpSettings',
        (
            ['out', 'retval'],
            POINTER(POINTER(INetFwIcmpSettings)),
            'IcmpSettings',
        )
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'GloballyOpenPorts',
        (['out', 'retval'], POINTER(POINTER(INetFwOpenPorts)), 'openPorts')
    ),
    COMMETHOD(
        [dispid(9), 'propget'],
        HRESULT,
        'Services',
        (['out', 'retval'], POINTER(POINTER(INetFwServices)), 'Services')
    ),
    COMMETHOD(
        [dispid(10), 'propget'],
        HRESULT,
        'AuthorizedApplications',
        (
            ['out', 'retval'],
            POINTER(POINTER(INetFwAuthorizedApplications)),
            'apps',
        )
    ),
]

################################################################
# code template for INetFwProfile implementation
# class INetFwProfile_Impl(object):
#     @property
#     def Type(self):
#         '-no docstring-'
#         #return Type
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     FirewallEnabled = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return notAllowed
#     def _set(self, notAllowed):
#         '-no docstring-'
#     ExceptionsNotAllowed = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return disabled
#     def _set(self, disabled):
#         '-no docstring-'
#     NotificationsDisabled = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return disabled
#     def _set(self, disabled):
#         '-no docstring-'
#     UnicastResponsesToMulticastBroadcastDisabled = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def RemoteAdminSettings(self):
#         '-no docstring-'
#         #return RemoteAdminSettings
#
#     @property
#     def IcmpSettings(self):
#         '-no docstring-'
#         #return IcmpSettings
#
#     @property
#     def GloballyOpenPorts(self):
#         '-no docstring-'
#         #return openPorts
#
#     @property
#     def Services(self):
#         '-no docstring-'
#         #return Services
#
#     @property
#     def AuthorizedApplications(self):
#         '-no docstring-'
#         #return apps
#


class INetFwAuthorizedApplication(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{B5E64FFA-C2C5-444E-A301-FB5E00018050}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Name(self) -> hints.Incomplete: ...
        def _set_Name(self, Name: hints.Incomplete) -> hints.Hresult: ...
        Name = hints.normal_property(_get_Name, _set_Name)
        def _get_ProcessImageFileName(self) -> hints.Incomplete: ...
        def _set_ProcessImageFileName(self, imageFileName: hints.Incomplete) -> hints.Hresult: ...
        ProcessImageFileName = hints.normal_property(_get_ProcessImageFileName, _set_ProcessImageFileName)
        def _get_IpVersion(self) -> hints.Incomplete: ...
        def _set_IpVersion(self, IpVersion: hints.Incomplete) -> hints.Hresult: ...
        IpVersion = hints.normal_property(_get_IpVersion, _set_IpVersion)
        def _get_Scope(self) -> hints.Incomplete: ...
        def _set_Scope(self, Scope: hints.Incomplete) -> hints.Hresult: ...
        Scope = hints.normal_property(_get_Scope, _set_Scope)
        def _get_RemoteAddresses(self) -> hints.Incomplete: ...
        def _set_RemoteAddresses(self, remoteAddrs: hints.Incomplete) -> hints.Hresult: ...
        RemoteAddresses = hints.normal_property(_get_RemoteAddresses, _set_RemoteAddresses)
        def _get_Enabled(self) -> hints.Incomplete: ...
        def _set_Enabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        Enabled = hints.normal_property(_get_Enabled, _set_Enabled)


INetFwAuthorizedApplication._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Name',
        (['out', 'retval'], POINTER(BSTR), 'Name')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'Name',
        (['in'], BSTR, 'Name')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'ProcessImageFileName',
        (['out', 'retval'], POINTER(BSTR), 'imageFileName')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'ProcessImageFileName',
        (['in'], BSTR, 'imageFileName')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'IpVersion',
        (['out', 'retval'], POINTER(NET_FW_IP_VERSION_), 'IpVersion')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'IpVersion',
        (['in'], NET_FW_IP_VERSION_, 'IpVersion')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'Scope',
        (['out', 'retval'], POINTER(NET_FW_SCOPE_), 'Scope')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'Scope',
        (['in'], NET_FW_SCOPE_, 'Scope')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'RemoteAddresses',
        (['out', 'retval'], POINTER(BSTR), 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'RemoteAddresses',
        (['in'], BSTR, 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'Enabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'Enabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
]

################################################################
# code template for INetFwAuthorizedApplication implementation
# class INetFwAuthorizedApplication_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return Name
#     def _set(self, Name):
#         '-no docstring-'
#     Name = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return imageFileName
#     def _set(self, imageFileName):
#         '-no docstring-'
#     ProcessImageFileName = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return IpVersion
#     def _set(self, IpVersion):
#         '-no docstring-'
#     IpVersion = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Scope
#     def _set(self, Scope):
#         '-no docstring-'
#     Scope = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return remoteAddrs
#     def _set(self, remoteAddrs):
#         '-no docstring-'
#     RemoteAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     Enabled = property(_get, _set, doc = _set.__doc__)
#


class INetFwRule2(INetFwRule):
    _case_insensitive_ = True
    _iid_ = GUID('{9C27C8DA-189B-4DDE-89F7-8B39A316782C}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_EdgeTraversalOptions(self) -> hints.Incomplete: ...
        def _set_EdgeTraversalOptions(self, lOptions: hints.Incomplete) -> hints.Hresult: ...
        EdgeTraversalOptions = hints.normal_property(_get_EdgeTraversalOptions, _set_EdgeTraversalOptions)


INetFwRule2._methods_ = [
    COMMETHOD(
        [dispid(19), 'propget'],
        HRESULT,
        'EdgeTraversalOptions',
        (['out', 'retval'], POINTER(c_int), 'lOptions')
    ),
    COMMETHOD(
        [dispid(19), 'propput'],
        HRESULT,
        'EdgeTraversalOptions',
        (['in'], c_int, 'lOptions')
    ),
]

################################################################
# code template for INetFwRule2 implementation
# class INetFwRule2_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return lOptions
#     def _set(self, lOptions):
#         '-no docstring-'
#     EdgeTraversalOptions = property(_get, _set, doc = _set.__doc__)
#

INetFwPolicy._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'CurrentProfile',
        (['out', 'retval'], POINTER(POINTER(INetFwProfile)), 'profile')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'GetProfileByType',
        (['in'], NET_FW_PROFILE_TYPE_, 'profileType'),
        (['out', 'retval'], POINTER(POINTER(INetFwProfile)), 'profile')
    ),
]

################################################################
# code template for INetFwPolicy implementation
# class INetFwPolicy_Impl(object):
#     @property
#     def CurrentProfile(self):
#         '-no docstring-'
#         #return profile
#
#     def GetProfileByType(self, profileType):
#         '-no docstring-'
#         #return profile
#


class INetFwRule3(INetFwRule2):
    _case_insensitive_ = True
    _iid_ = GUID('{B21563FF-D696-4222-AB46-4E89B73AB34A}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_LocalAppPackageId(self) -> hints.Incomplete: ...
        def _set_LocalAppPackageId(self, wszPackageId: hints.Incomplete) -> hints.Hresult: ...
        LocalAppPackageId = hints.normal_property(_get_LocalAppPackageId, _set_LocalAppPackageId)
        def _get_LocalUserOwner(self) -> hints.Incomplete: ...
        def _set_LocalUserOwner(self, wszUserOwner: hints.Incomplete) -> hints.Hresult: ...
        LocalUserOwner = hints.normal_property(_get_LocalUserOwner, _set_LocalUserOwner)
        def _get_LocalUserAuthorizedList(self) -> hints.Incomplete: ...
        def _set_LocalUserAuthorizedList(self, wszUserAuthList: hints.Incomplete) -> hints.Hresult: ...
        LocalUserAuthorizedList = hints.normal_property(_get_LocalUserAuthorizedList, _set_LocalUserAuthorizedList)
        def _get_RemoteUserAuthorizedList(self) -> hints.Incomplete: ...
        def _set_RemoteUserAuthorizedList(self, wszUserAuthList: hints.Incomplete) -> hints.Hresult: ...
        RemoteUserAuthorizedList = hints.normal_property(_get_RemoteUserAuthorizedList, _set_RemoteUserAuthorizedList)
        def _get_RemoteMachineAuthorizedList(self) -> hints.Incomplete: ...
        def _set_RemoteMachineAuthorizedList(self, wszUserAuthList: hints.Incomplete) -> hints.Hresult: ...
        RemoteMachineAuthorizedList = hints.normal_property(_get_RemoteMachineAuthorizedList, _set_RemoteMachineAuthorizedList)
        def _get_SecureFlags(self) -> hints.Incomplete: ...
        def _set_SecureFlags(self, lOptions: hints.Incomplete) -> hints.Hresult: ...
        SecureFlags = hints.normal_property(_get_SecureFlags, _set_SecureFlags)


INetFwRule3._methods_ = [
    COMMETHOD(
        [dispid(20), 'propget'],
        HRESULT,
        'LocalAppPackageId',
        (['out', 'retval'], POINTER(BSTR), 'wszPackageId')
    ),
    COMMETHOD(
        [dispid(20), 'propput'],
        HRESULT,
        'LocalAppPackageId',
        (['in'], BSTR, 'wszPackageId')
    ),
    COMMETHOD(
        [dispid(21), 'propget'],
        HRESULT,
        'LocalUserOwner',
        (['out', 'retval'], POINTER(BSTR), 'wszUserOwner')
    ),
    COMMETHOD(
        [dispid(21), 'propput'],
        HRESULT,
        'LocalUserOwner',
        (['in'], BSTR, 'wszUserOwner')
    ),
    COMMETHOD(
        [dispid(22), 'propget'],
        HRESULT,
        'LocalUserAuthorizedList',
        (['out', 'retval'], POINTER(BSTR), 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(22), 'propput'],
        HRESULT,
        'LocalUserAuthorizedList',
        (['in'], BSTR, 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(23), 'propget'],
        HRESULT,
        'RemoteUserAuthorizedList',
        (['out', 'retval'], POINTER(BSTR), 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(23), 'propput'],
        HRESULT,
        'RemoteUserAuthorizedList',
        (['in'], BSTR, 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(24), 'propget'],
        HRESULT,
        'RemoteMachineAuthorizedList',
        (['out', 'retval'], POINTER(BSTR), 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(24), 'propput'],
        HRESULT,
        'RemoteMachineAuthorizedList',
        (['in'], BSTR, 'wszUserAuthList')
    ),
    COMMETHOD(
        [dispid(25), 'propget'],
        HRESULT,
        'SecureFlags',
        (['out', 'retval'], POINTER(c_int), 'lOptions')
    ),
    COMMETHOD(
        [dispid(25), 'propput'],
        HRESULT,
        'SecureFlags',
        (['in'], c_int, 'lOptions')
    ),
]

################################################################
# code template for INetFwRule3 implementation
# class INetFwRule3_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return wszPackageId
#     def _set(self, wszPackageId):
#         '-no docstring-'
#     LocalAppPackageId = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return wszUserOwner
#     def _set(self, wszUserOwner):
#         '-no docstring-'
#     LocalUserOwner = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return wszUserAuthList
#     def _set(self, wszUserAuthList):
#         '-no docstring-'
#     LocalUserAuthorizedList = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return wszUserAuthList
#     def _set(self, wszUserAuthList):
#         '-no docstring-'
#     RemoteUserAuthorizedList = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return wszUserAuthList
#     def _set(self, wszUserAuthList):
#         '-no docstring-'
#     RemoteMachineAuthorizedList = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return lOptions
#     def _set(self, lOptions):
#         '-no docstring-'
#     SecureFlags = property(_get, _set, doc = _set.__doc__)
#


class INetFwService(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{79FD57C8-908E-4A36-9888-D5B3F0A444CF}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Name(self) -> hints.Incomplete: ...
        Name = hints.normal_property(_get_Name)
        def _get_Type(self) -> hints.Incomplete: ...
        Type = hints.normal_property(_get_Type)
        def _get_Customized(self) -> hints.Incomplete: ...
        Customized = hints.normal_property(_get_Customized)
        def _get_IpVersion(self) -> hints.Incomplete: ...
        def _set_IpVersion(self, IpVersion: hints.Incomplete) -> hints.Hresult: ...
        IpVersion = hints.normal_property(_get_IpVersion, _set_IpVersion)
        def _get_Scope(self) -> hints.Incomplete: ...
        def _set_Scope(self, Scope: hints.Incomplete) -> hints.Hresult: ...
        Scope = hints.normal_property(_get_Scope, _set_Scope)
        def _get_RemoteAddresses(self) -> hints.Incomplete: ...
        def _set_RemoteAddresses(self, remoteAddrs: hints.Incomplete) -> hints.Hresult: ...
        RemoteAddresses = hints.normal_property(_get_RemoteAddresses, _set_RemoteAddresses)
        def _get_Enabled(self) -> hints.Incomplete: ...
        def _set_Enabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        Enabled = hints.normal_property(_get_Enabled, _set_Enabled)
        def _get_GloballyOpenPorts(self) -> 'INetFwOpenPorts': ...
        GloballyOpenPorts = hints.normal_property(_get_GloballyOpenPorts)


INetFwService._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Name',
        (['out', 'retval'], POINTER(BSTR), 'Name')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'Type',
        (['out', 'retval'], POINTER(NET_FW_SERVICE_TYPE_), 'Type')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'Customized',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Customized')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'IpVersion',
        (['out', 'retval'], POINTER(NET_FW_IP_VERSION_), 'IpVersion')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'IpVersion',
        (['in'], NET_FW_IP_VERSION_, 'IpVersion')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'Scope',
        (['out', 'retval'], POINTER(NET_FW_SCOPE_), 'Scope')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'Scope',
        (['in'], NET_FW_SCOPE_, 'Scope')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'RemoteAddresses',
        (['out', 'retval'], POINTER(BSTR), 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'RemoteAddresses',
        (['in'], BSTR, 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'Enabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(7), 'propput'],
        HRESULT,
        'Enabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'GloballyOpenPorts',
        (['out', 'retval'], POINTER(POINTER(INetFwOpenPorts)), 'openPorts')
    ),
]

################################################################
# code template for INetFwService implementation
# class INetFwService_Impl(object):
#     @property
#     def Name(self):
#         '-no docstring-'
#         #return Name
#
#     @property
#     def Type(self):
#         '-no docstring-'
#         #return Type
#
#     @property
#     def Customized(self):
#         '-no docstring-'
#         #return Customized
#
#     def _get(self):
#         '-no docstring-'
#         #return IpVersion
#     def _set(self, IpVersion):
#         '-no docstring-'
#     IpVersion = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Scope
#     def _set(self, Scope):
#         '-no docstring-'
#     Scope = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return remoteAddrs
#     def _set(self, remoteAddrs):
#         '-no docstring-'
#     RemoteAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     Enabled = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def GloballyOpenPorts(self):
#         '-no docstring-'
#         #return openPorts
#


class INetFwOpenPort(comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0.IDispatch):
    _case_insensitive_ = True
    _iid_ = GUID('{E0483BA0-47FF-4D9C-A6D6-7741D0B195F7}')
    _idlflags_ = ['dual', 'oleautomation']

    if TYPE_CHECKING:  # commembers
        def _get_Name(self) -> hints.Incomplete: ...
        def _set_Name(self, Name: hints.Incomplete) -> hints.Hresult: ...
        Name = hints.normal_property(_get_Name, _set_Name)
        def _get_IpVersion(self) -> hints.Incomplete: ...
        def _set_IpVersion(self, IpVersion: hints.Incomplete) -> hints.Hresult: ...
        IpVersion = hints.normal_property(_get_IpVersion, _set_IpVersion)
        def _get_Protocol(self) -> hints.Incomplete: ...
        def _set_Protocol(self, ipProtocol: hints.Incomplete) -> hints.Hresult: ...
        Protocol = hints.normal_property(_get_Protocol, _set_Protocol)
        def _get_Port(self) -> hints.Incomplete: ...
        def _set_Port(self, portNumber: hints.Incomplete) -> hints.Hresult: ...
        Port = hints.normal_property(_get_Port, _set_Port)
        def _get_Scope(self) -> hints.Incomplete: ...
        def _set_Scope(self, Scope: hints.Incomplete) -> hints.Hresult: ...
        Scope = hints.normal_property(_get_Scope, _set_Scope)
        def _get_RemoteAddresses(self) -> hints.Incomplete: ...
        def _set_RemoteAddresses(self, remoteAddrs: hints.Incomplete) -> hints.Hresult: ...
        RemoteAddresses = hints.normal_property(_get_RemoteAddresses, _set_RemoteAddresses)
        def _get_Enabled(self) -> hints.Incomplete: ...
        def _set_Enabled(self, Enabled: hints.Incomplete) -> hints.Hresult: ...
        Enabled = hints.normal_property(_get_Enabled, _set_Enabled)
        def _get_BuiltIn(self) -> hints.Incomplete: ...
        BuiltIn = hints.normal_property(_get_BuiltIn)


INetFwOpenPort._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Name',
        (['out', 'retval'], POINTER(BSTR), 'Name')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'Name',
        (['in'], BSTR, 'Name')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'IpVersion',
        (['out', 'retval'], POINTER(NET_FW_IP_VERSION_), 'IpVersion')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'IpVersion',
        (['in'], NET_FW_IP_VERSION_, 'IpVersion')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'Protocol',
        (['out', 'retval'], POINTER(NET_FW_IP_PROTOCOL_), 'ipProtocol')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'Protocol',
        (['in'], NET_FW_IP_PROTOCOL_, 'ipProtocol')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'Port',
        (['out', 'retval'], POINTER(c_int), 'portNumber')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'Port',
        (['in'], c_int, 'portNumber')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'Scope',
        (['out', 'retval'], POINTER(NET_FW_SCOPE_), 'Scope')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'Scope',
        (['in'], NET_FW_SCOPE_, 'Scope')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'RemoteAddresses',
        (['out', 'retval'], POINTER(BSTR), 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'RemoteAddresses',
        (['in'], BSTR, 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'Enabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(7), 'propput'],
        HRESULT,
        'Enabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'BuiltIn',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'BuiltIn')
    ),
]

################################################################
# code template for INetFwOpenPort implementation
# class INetFwOpenPort_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return Name
#     def _set(self, Name):
#         '-no docstring-'
#     Name = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return IpVersion
#     def _set(self, IpVersion):
#         '-no docstring-'
#     IpVersion = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return ipProtocol
#     def _set(self, ipProtocol):
#         '-no docstring-'
#     Protocol = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return portNumber
#     def _set(self, portNumber):
#         '-no docstring-'
#     Port = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Scope
#     def _set(self, Scope):
#         '-no docstring-'
#     Scope = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return remoteAddrs
#     def _set(self, remoteAddrs):
#         '-no docstring-'
#     RemoteAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     Enabled = property(_get, _set, doc = _set.__doc__)
#
#     @property
#     def BuiltIn(self):
#         '-no docstring-'
#         #return BuiltIn
#

INetFwRules._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Count',
        (['out', 'retval'], POINTER(c_int), 'Count')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'Add',
        (['in'], POINTER(INetFwRule), 'rule')
    ),
    COMMETHOD(
        [dispid(3)],
        HRESULT,
        'Remove',
        (['in'], BSTR, 'Name')
    ),
    COMMETHOD(
        [dispid(4)],
        HRESULT,
        'Item',
        (['in'], BSTR, 'Name'),
        (['out', 'retval'], POINTER(POINTER(INetFwRule)), 'rule')
    ),
    COMMETHOD(
        [dispid(-4), 'restricted', 'propget'],
        HRESULT,
        '_NewEnum',
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'newEnum')
    ),
]

################################################################
# code template for INetFwRules implementation
# class INetFwRules_Impl(object):
#     @property
#     def Count(self):
#         '-no docstring-'
#         #return Count
#
#     def Add(self, rule):
#         '-no docstring-'
#         #return 
#
#     def Remove(self, Name):
#         '-no docstring-'
#         #return 
#
#     def Item(self, Name):
#         '-no docstring-'
#         #return rule
#
#     @property
#     def _NewEnum(self):
#         '-no docstring-'
#         #return newEnum
#

INetFwOpenPorts._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Count',
        (['out', 'retval'], POINTER(c_int), 'Count')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'Add',
        (['in'], POINTER(INetFwOpenPort), 'Port')
    ),
    COMMETHOD(
        [dispid(3)],
        HRESULT,
        'Remove',
        (['in'], c_int, 'portNumber'),
        (['in'], NET_FW_IP_PROTOCOL_, 'ipProtocol')
    ),
    COMMETHOD(
        [dispid(4)],
        HRESULT,
        'Item',
        (['in'], c_int, 'portNumber'),
        (['in'], NET_FW_IP_PROTOCOL_, 'ipProtocol'),
        (['out', 'retval'], POINTER(POINTER(INetFwOpenPort)), 'openPort')
    ),
    COMMETHOD(
        [dispid(-4), 'restricted', 'propget'],
        HRESULT,
        '_NewEnum',
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'newEnum')
    ),
]

################################################################
# code template for INetFwOpenPorts implementation
# class INetFwOpenPorts_Impl(object):
#     @property
#     def Count(self):
#         '-no docstring-'
#         #return Count
#
#     def Add(self, Port):
#         '-no docstring-'
#         #return 
#
#     def Remove(self, portNumber, ipProtocol):
#         '-no docstring-'
#         #return 
#
#     def Item(self, portNumber, ipProtocol):
#         '-no docstring-'
#         #return openPort
#
#     @property
#     def _NewEnum(self):
#         '-no docstring-'
#         #return newEnum
#

INetFwAuthorizedApplications._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Count',
        (['out', 'retval'], POINTER(c_int), 'Count')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'Add',
        (['in'], POINTER(INetFwAuthorizedApplication), 'app')
    ),
    COMMETHOD(
        [dispid(3)],
        HRESULT,
        'Remove',
        (['in'], BSTR, 'imageFileName')
    ),
    COMMETHOD(
        [dispid(4)],
        HRESULT,
        'Item',
        (['in'], BSTR, 'imageFileName'),
        (
            ['out', 'retval'],
            POINTER(POINTER(INetFwAuthorizedApplication)),
            'app',
        )
    ),
    COMMETHOD(
        [dispid(-4), 'restricted', 'propget'],
        HRESULT,
        '_NewEnum',
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'newEnum')
    ),
]

################################################################
# code template for INetFwAuthorizedApplications implementation
# class INetFwAuthorizedApplications_Impl(object):
#     @property
#     def Count(self):
#         '-no docstring-'
#         #return Count
#
#     def Add(self, app):
#         '-no docstring-'
#         #return 
#
#     def Remove(self, imageFileName):
#         '-no docstring-'
#         #return 
#
#     def Item(self, imageFileName):
#         '-no docstring-'
#         #return app
#
#     @property
#     def _NewEnum(self):
#         '-no docstring-'
#         #return newEnum
#

INetFwIcmpSettings._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'AllowOutboundDestinationUnreachable',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'AllowOutboundDestinationUnreachable',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'AllowRedirect',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'AllowRedirect',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'AllowInboundEchoRequest',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'AllowInboundEchoRequest',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'AllowOutboundTimeExceeded',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'AllowOutboundTimeExceeded',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(5), 'propget'],
        HRESULT,
        'AllowOutboundParameterProblem',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(5), 'propput'],
        HRESULT,
        'AllowOutboundParameterProblem',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(6), 'propget'],
        HRESULT,
        'AllowOutboundSourceQuench',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(6), 'propput'],
        HRESULT,
        'AllowOutboundSourceQuench',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(7), 'propget'],
        HRESULT,
        'AllowInboundRouterRequest',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(7), 'propput'],
        HRESULT,
        'AllowInboundRouterRequest',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(8), 'propget'],
        HRESULT,
        'AllowInboundTimestampRequest',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(8), 'propput'],
        HRESULT,
        'AllowInboundTimestampRequest',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(9), 'propget'],
        HRESULT,
        'AllowInboundMaskRequest',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(9), 'propput'],
        HRESULT,
        'AllowInboundMaskRequest',
        (['in'], VARIANT_BOOL, 'allow')
    ),
    COMMETHOD(
        [dispid(10), 'propget'],
        HRESULT,
        'AllowOutboundPacketTooBig',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'allow')
    ),
    COMMETHOD(
        [dispid(10), 'propput'],
        HRESULT,
        'AllowOutboundPacketTooBig',
        (['in'], VARIANT_BOOL, 'allow')
    ),
]

################################################################
# code template for INetFwIcmpSettings implementation
# class INetFwIcmpSettings_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowOutboundDestinationUnreachable = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowRedirect = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowInboundEchoRequest = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowOutboundTimeExceeded = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowOutboundParameterProblem = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowOutboundSourceQuench = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowInboundRouterRequest = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowInboundTimestampRequest = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowInboundMaskRequest = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return allow
#     def _set(self, allow):
#         '-no docstring-'
#     AllowOutboundPacketTooBig = property(_get, _set, doc = _set.__doc__)
#


class Library(object):
    name = 'NetFwTypeLib'
    _reg_typelib_ = ('{58FBCF7C-E7A9-467C-80B3-FC65E8FCCA08}', 1, 0)


INetFwRemoteAdminSettings._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'IpVersion',
        (['out', 'retval'], POINTER(NET_FW_IP_VERSION_), 'IpVersion')
    ),
    COMMETHOD(
        [dispid(1), 'propput'],
        HRESULT,
        'IpVersion',
        (['in'], NET_FW_IP_VERSION_, 'IpVersion')
    ),
    COMMETHOD(
        [dispid(2), 'propget'],
        HRESULT,
        'Scope',
        (['out', 'retval'], POINTER(NET_FW_SCOPE_), 'Scope')
    ),
    COMMETHOD(
        [dispid(2), 'propput'],
        HRESULT,
        'Scope',
        (['in'], NET_FW_SCOPE_, 'Scope')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'RemoteAddresses',
        (['out', 'retval'], POINTER(BSTR), 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(3), 'propput'],
        HRESULT,
        'RemoteAddresses',
        (['in'], BSTR, 'remoteAddrs')
    ),
    COMMETHOD(
        [dispid(4), 'propget'],
        HRESULT,
        'Enabled',
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'Enabled')
    ),
    COMMETHOD(
        [dispid(4), 'propput'],
        HRESULT,
        'Enabled',
        (['in'], VARIANT_BOOL, 'Enabled')
    ),
]

################################################################
# code template for INetFwRemoteAdminSettings implementation
# class INetFwRemoteAdminSettings_Impl(object):
#     def _get(self):
#         '-no docstring-'
#         #return IpVersion
#     def _set(self, IpVersion):
#         '-no docstring-'
#     IpVersion = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Scope
#     def _set(self, Scope):
#         '-no docstring-'
#     Scope = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return remoteAddrs
#     def _set(self, remoteAddrs):
#         '-no docstring-'
#     RemoteAddresses = property(_get, _set, doc = _set.__doc__)
#
#     def _get(self):
#         '-no docstring-'
#         #return Enabled
#     def _set(self, Enabled):
#         '-no docstring-'
#     Enabled = property(_get, _set, doc = _set.__doc__)
#

INetFwServiceRestriction._methods_ = [
    COMMETHOD(
        [dispid(1)],
        HRESULT,
        'RestrictService',
        (['in'], BSTR, 'serviceName'),
        (['in'], BSTR, 'appName'),
        (['in'], VARIANT_BOOL, 'RestrictService'),
        (['in'], VARIANT_BOOL, 'serviceSidRestricted')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'ServiceRestricted',
        (['in'], BSTR, 'serviceName'),
        (['in'], BSTR, 'appName'),
        (['out', 'retval'], POINTER(VARIANT_BOOL), 'ServiceRestricted')
    ),
    COMMETHOD(
        [dispid(3), 'propget'],
        HRESULT,
        'Rules',
        (['out', 'retval'], POINTER(POINTER(INetFwRules)), 'Rules')
    ),
]

################################################################
# code template for INetFwServiceRestriction implementation
# class INetFwServiceRestriction_Impl(object):
#     def RestrictService(self, serviceName, appName, RestrictService, serviceSidRestricted):
#         '-no docstring-'
#         #return 
#
#     def ServiceRestricted(self, serviceName, appName):
#         '-no docstring-'
#         #return ServiceRestricted
#
#     @property
#     def Rules(self):
#         '-no docstring-'
#         #return Rules
#

INetFwServices._methods_ = [
    COMMETHOD(
        [dispid(1), 'propget'],
        HRESULT,
        'Count',
        (['out', 'retval'], POINTER(c_int), 'Count')
    ),
    COMMETHOD(
        [dispid(2)],
        HRESULT,
        'Item',
        (['in'], NET_FW_SERVICE_TYPE_, 'svcType'),
        (['out', 'retval'], POINTER(POINTER(INetFwService)), 'service')
    ),
    COMMETHOD(
        [dispid(-4), 'restricted', 'propget'],
        HRESULT,
        '_NewEnum',
        (['out', 'retval'], POINTER(POINTER(IUnknown)), 'newEnum')
    ),
]

################################################################
# code template for INetFwServices implementation
# class INetFwServices_Impl(object):
#     @property
#     def Count(self):
#         '-no docstring-'
#         #return Count
#
#     def Item(self, svcType):
#         '-no docstring-'
#         #return service
#
#     @property
#     def _NewEnum(self):
#         '-no docstring-'
#         #return newEnum
#

__all__ = [
    'NET_FW_IP_VERSION_MAX', 'NET_FW_ACTION_ALLOW', 'Library',
    'NET_FW_PROFILE2_DOMAIN', 'NET_FW_PROFILE2_ALL',
    'INetFwAuthorizedApplication', 'NET_FW_MODIFY_STATE_GP_OVERRIDE',
    'NET_FW_SERVICE_FILE_AND_PRINT', 'NET_FW_SCOPE_CUSTOM',
    'NET_FW_SERVICE_REMOTE_DESKTOP', 'INetFwRule2',
    'NET_FW_PROFILE_STANDARD', 'NET_FW_PROFILE_TYPE_',
    'NET_FW_PROFILE_DOMAIN', 'INetFwService',
    'INetFwRemoteAdminSettings', 'NET_FW_SCOPE_ALL',
    'NET_FW_SERVICE_TYPE_MAX', 'NET_FW_PROFILE_TYPE_MAX',
    'NET_FW_PROFILE_CURRENT', 'INetFwAuthorizedApplications',
    'NET_FW_IP_PROTOCOL_ANY', 'NET_FW_RULE_DIRECTION_',
    'NET_FW_IP_VERSION_V4', 'INetFwPolicy2', 'NET_FW_RULE_DIR_OUT',
    'NET_FW_PROFILE2_PUBLIC', 'NET_FW_RULE_DIR_MAX',
    'NET_FW_ACTION_MAX', 'INetFwRule', 'NET_FW_SERVICE_NONE',
    'INetFwMgr', 'INetFwOpenPort', 'NET_FW_SCOPE_LOCAL_SUBNET',
    'NET_FW_SCOPE_MAX', 'INetFwOpenPorts', 'NET_FW_IP_VERSION_V6',
    'NET_FW_IP_PROTOCOL_TCP', 'NET_FW_RULE_DIR_IN', 'INetFwPolicy',
    'INetFwServiceRestriction', 'NET_FW_SCOPE_', 'NET_FW_ACTION_',
    'INetFwProfile', 'NET_FW_IP_VERSION_ANY', 'NET_FW_IP_PROTOCOL_',
    'NET_FW_IP_VERSION_', 'NET_FW_MODIFY_STATE_INBOUND_BLOCKED',
    'INetFwProducts', 'NET_FW_SERVICE_UPNP', 'NET_FW_PROFILE_TYPE2_',
    'INetFwRules', 'INetFwProduct', 'INetFwServices',
    'NET_FW_MODIFY_STATE_OK', 'NET_FW_PROFILE2_PRIVATE',
    'INetFwIcmpSettings', 'NET_FW_IP_PROTOCOL_UDP',
    'NET_FW_MODIFY_STATE_', 'INetFwRule3', 'NET_FW_ACTION_BLOCK',
    'typelib_path', 'NET_FW_SERVICE_TYPE_'
]

_check_version('1.4.17', 1792344676.440232)

